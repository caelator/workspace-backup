# GitNexus embedding config aligned with Memoryport's local embedding model/proxy.
export GITNEXUS_EMBEDDING_URL="http://127.0.0.1:11434/v1"
export GITNEXUS_EMBEDDING_MODEL="nomic-embed-text"
export GITNEXUS_EMBEDDING_DIMS="768"
export GITNEXUS_EMBEDDING_API_KEY="unused"
